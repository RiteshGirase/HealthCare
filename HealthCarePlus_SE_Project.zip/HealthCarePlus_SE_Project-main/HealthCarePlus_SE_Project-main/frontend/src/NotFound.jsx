import React from "react";

function NotFound() {
  return (
    <div>
      <h2 style={{ margin: "70px" }}>This Path is not available</h2>
    </div>
  );
}

export default NotFound;

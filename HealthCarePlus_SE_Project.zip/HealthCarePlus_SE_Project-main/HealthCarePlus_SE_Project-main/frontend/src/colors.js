export const colors = {
  primary: "#396F78",
  secondary: "#4DADBD",
  darkBrown: "#4F3928",
  lightBrown: "#7C4F35",
  primaryYellow: "#DADF74",
  grey: "#CEB699",
  white: "#ffffff",
  secondaryWhite: "#FBFBFB",
  black: "#000000",
  error: "#FF9494",
};

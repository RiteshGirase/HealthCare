import React from "react";

const Apppointments = () => {
  return (
    <>
      <div>Hello</div>
    </>
  );
};

export default Apppointments;

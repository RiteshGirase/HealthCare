import React from "react";
import { Outlet } from "react-router-dom";

function Medicine() {
  return <Outlet />;
}

export default Medicine;

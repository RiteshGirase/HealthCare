import React from "react";
import { Outlet } from "react-router-dom";

function Doctor() {
  return <Outlet />;
}

export default Doctor;

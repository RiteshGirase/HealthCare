import { Outlet } from "react-router-dom";
import React from "react";

const User = () => {
  return <Outlet />;
};

export default User;

import { Outlet } from "react-router-dom";

export default function User() {
    return (
        <Outlet />
    )
}
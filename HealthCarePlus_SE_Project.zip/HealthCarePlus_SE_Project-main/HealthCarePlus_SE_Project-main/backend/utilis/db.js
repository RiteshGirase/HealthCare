const mongoose = require("mongoose");

mongoose.set("strictQuery", true);

mongoose.connect("mongodb+srv://sonipratham64:pratham@cluster1.rbfkqmd.mongodb.net/?retryWrites=true&w=majority&appName=Cluster1", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on("error", () => {
  console.log("Failed to Connect MongoDb");
});

db.once("open", () => {
  console.log("Connected To MongoDB");
});